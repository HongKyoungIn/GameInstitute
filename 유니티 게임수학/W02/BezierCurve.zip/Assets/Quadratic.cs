using UnityEngine;

public class Quadratic : MonoBehaviour {
    public Transform[] point;

    private float ellipsedTime;
    private float moveSpeed = 2f;

    private void Update() {
        ellipsedTime += Time.deltaTime;

        float t = ellipsedTime / moveSpeed;
        if (t >= 1f) {
            ellipsedTime = 0f;
        }
        transform.position = CalculateBezierPoint(t, point[0].position, point[1].position, point[2].position); ;
    }

    // ������ � ���� �� ���
    private Vector3 CalculateBezierPoint(float t, Vector3 p0, Vector3 p1, Vector3 p2) {
        Vector3 Bp0p1 = (1f - t) * p0 + t * p1;
        Vector3 Bp1p2 = (1f - t) * p1 + t * p2;
        return (1f - t) * Bp0p1 + t * Bp1p2;
    }
}